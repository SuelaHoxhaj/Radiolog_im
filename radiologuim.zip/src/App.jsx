import React from 'react';

function App() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '2rem' }}>
      <h1>Radiologu Im</h1>
      <p>Platformë informative për radiologjinë në Shqipëri.</p>
    </div>
  );
}

export default App;
